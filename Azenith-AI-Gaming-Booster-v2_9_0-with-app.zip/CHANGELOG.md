# Changelog Azenith-AI Gaming Booster

## v2.9.0
- **Companion App (APK) ikut di dalam module.** UI app = WebUI module (halaman yang sama persis,
  dibaca langsung dari `webroot/` module yang terpasang, jadi update module = update tampilan app
  tanpa build ulang APK). Semua fitur tetap dijalankan oleh module (`azenith-ai` CLI + daemon);
  app hanya menampilkan UI dan menyalurkan perintah ke module lewat shell root (jembatan
  `ksu.exec` yang sama seperti di WebUI Manager). App tidak meminta izin INTERNET.
- `lib/app_install.sh` baru: pasang/upgrade app otomatis dari `app/AzenithAI-Companion.apk` saat boot
  (APK disalin dulu ke /data/local/tmp karena `pm` tidak selalu bisa membaca /data/adb), cek checksum
  supaya tidak dipasang ulang tiap boot, dan copot-lalu-pasang kalau signature APK berbeda.
- `action.sh`: tombol Action sekarang membuka app (memasangnya dulu kalau belum ada).
- Dibuang: `AndroidManifest.xml` biner sisa APK lama di root zip (tidak dipakai module dan package-nya
  `com.azettech.azenithai` tidak sama dengan yang dipakai script, `com.azenithtech.azenithai`).

## v2.8.0
- **Kembali jadi SATU module saja** (app companion APK terpisah - yang sempat dibuat lewat
  Termux+GitHub Actions - dihentikan: ribet soal signing/install, dan tidak perlu karena
  Manager root sudah menyediakan UI-nya sendiri). Semua interaksi sekarang lewat Manager
  (Magisk/KernelSU/APatch) setelah flash zip → reboot, seperti v1-v2.7.x.
- **`action.sh` dikembalikan** (sempat dihapus di versi lama): tombol **Action** di Manager
  sekarang menjalankan "terapkan ulang sekarang" - reassert Disable Thermal, restart daemon
  tuning, lalu cetak ringkasan status ke log Action. Modul jadi tampil dengan 2 tombol di
  Manager: **Action** dan **WebUI** (`webroot/`, sudah ada sejak lama).
- **Disable Thermal tetap seperti v2.7.2**: bukan toggle WebUI, otomatis permanen sejak boot,
  tidak pernah mati sendiri. Tidak ada perubahan perilaku di bagian ini, cuma ditegaskan ulang
  supaya tidak ada yang coba menambah toggle manual untuknya lagi.
- WebUI/KernelSU Manager/APatch Manager bisa bikin shortcut icon ke WebUI modul ini di
  homescreen (lihat bagian "Install" di README) - itu yang jadi "ikon di homescreen" untuk
  modul ini, bukan APK terpisah.

## v2.7.2
- **Disable Thermal jadi fitur inti PERMANEN**: dihapus dari toggle tab Kontrol sepenuhnya (tidak bisa dimatikan dari WebUI lagi). `THERMAL_KILL=1` dipaksa oleh `customize.sh` (saat install/update, termasuk upgrade dari conf lama yang masih `0`) dan `service.sh` (setiap boot, menulis ulang conf kalau perlu) sebelum watchdog `tkloop.sh` dijalankan - tidak lagi bergantung pada nilai tersimpan di conf. Tab Status sekarang menampilkan status Disable Thermal sebagai info saja (read-only), tombol diagnosa manual ("Verifikasi status", "Paksa terapkan sekarang") dipindah ke tab Alat.
- **Bypass Thermal dihapus dari WebUI** (kartu di tab Kontrol dibuang): dulu saling kunci dengan Disable Thermal dan bisa diam-diam mematikannya kalau Bypass dinyalakan - sekarang karena Disable Thermal permanen, `bypass on` (CLI) langsung DITOLAK dengan pesan jelas selama Disable Thermal aktif, tidak lagi mematikan Disable Thermal otomatis. Kalau conf lama entah bagaimana masih `BYPASS_THERMAL=1`, Disable Thermal yang melepasnya otomatis saat start, bukan sebaliknya - Disable Thermal selalu menang.

## v2.7.1
- Rebrand penuh dari ThermalX ke **Azenith-AI** (id module, nama CLI `azenith-ai`, path data `/data/adb/azenith-ai`, semua teks WebUI/script)
- **Disable Thermal**: auto-off pengaman panas (10 detik) DIHAPUS atas permintaan user. Sekarang fitur hanya mati lewat perintah manual (`azenith-ai thermalkill off` / tombol di WebUI), tidak lagi otomatis mengembalikan thermal walau baterai/skin/SoC terdeteksi panas. Deteksi suhu tetap jalan tapi cuma dicatat ke log, bukan memicu auto-revert.

# Changelog Azenith-AI Gaming Booster

## v2.7.0
- **RAM terpakai lebih akurat**: dua perbaikan pada rumus di WebUI (`lib/devinfo.sh` + `webroot/index.html`).
  1. Toleransi pembulatan RAM ke ukuran pasaran dinaikkan dari 2% ke 20% (`gib*0.98` -> `gib*0.80`). Dengan toleransi 2%, device yang cadangan RAM firmware-nya (modem/NPU/ISP kamera) di atas 2% dari total - umum terjadi di chipset low-end seperti MT6789/Transsion - salah dibulatkan ke ukuran pasaran SATU TINGKAT LEBIH RENDAH (mis. device 6GB terbaca kernel cuma ~5.2GB dibulatkan jadi "4GB", bukan "6GB"), bikin RAM terpakai % tampil jauh ngaco dari spek asli. Ini akar masalah utamanya.
  2. "Tersedia" sekarang memakai `MemAvailable` kernel LANGSUNG kalau ada (bukan selalu `min()` dengan rekonstruksi manual `MemFree+Cache`) - `MemAvailable` itu sendiri sudah memperhitungkan watermark & yang benar-benar reklaim-able (dipakai juga oleh Low Memory Killer Android), jadi lebih akurat daripada tebakan manual. `MemFree+Cache` manual cuma dipakai untuk kernel lama (<3.14) yang tidak punya `MemAvailable` sama sekali.
  3. Baris baru "Dicadangkan firmware" (RAM terpakai) menampilkan selisih nominal vs `MemTotal` supaya kelihatan jelas berapa yang memang tidak pernah bisa dipakai siapa pun (bukan "dipakai aplikasi").
- **Bypass Charging (baru, NYATA - bukan toggle visual)**: `lib/charge.sh` + `lib/chargeloop.sh`, toggle baru di tab Kontrol, CLI `azenith-ai charge on|off|status`. Mencari & menulis node kontrol charger asli di `/sys/class/power_supply/*/*` (urutan: `charging_enabled`/sejenisnya dulu, lalu `input_suspend`, baru batas arus ke 0 sebagai jalan terakhir), lalu **membaca ulang status baterai** (`power_supply/battery/status`) untuk memastikan benar-benar berubah dari `Charging` sebelum melaporkan aktif - kalau tidak ada node yang terbukti berefek nyata, fitur **menolak aktif** dan bilang tidak didukung di device itu, tidak pernah berpura-pura sukses. Watchdog latar belakang menulis ulang node tiap `CHARGE_TICK` detik (sebagian charger IC/HAL mengembalikan nilainya sendiri), dan otomatis MATI kalau: charger dicabut, baterai turun ke `CHARGE_MIN_PCT` (default 20%, anti over-discharge saat beban main lebih besar dari daya charger), atau node ternyata berhenti efektif (status balik `Charging` 3x berturut). Tahan reboot (`service.sh` menjalankan ulang watchdog kalau `CHARGE_BYPASS=1`); `uninstall.sh` SELALU mengembalikan node ke nilai asal supaya device tidak pernah tertinggal dalam kondisi tidak bisa charge.
- **Kestabilan ping/jaringan**: `network_apply` (bagian N) sekarang juga mematikan `wifi_suspend_optimizations_enabled` + `wifi_scan_throttle_enabled` selama main (sumber umum "ping merah" mendadak akibat WiFi power-save/scan background), menambahkan game aktif ke whitelist Doze/App Standby (`dumpsys deviceidle whitelist`) supaya koneksinya tidak ditahan sistem di background, dan `net.ipv4.tcp_fastopen=3`. Monitor ping (`NET_PING_LOG=1`, toggle baru di tab Status) sekarang menghitung avg/jitter/packet-loss NYATA dari ringkasan `ping` apa adanya (bukan dikarang di JS) tiap `NET_PING_INTERVAL` detik, ditampilkan sebagai label "Stabil / Kurang stabil / Tidak stabil" di kartu baru **Jaringan**. Packet loss >=20% memicu re-assert WiFi low-latency mode otomatis.

## v2.6.1
- **RAM akurat**: total sekarang dibulatkan ke ukuran fisik pasaran (mis. kernel membaca 7,25 GB -> tampil 8 GB) dan angka memakai basis biner (8 GB RAM = 8 GiB), jadi tidak lagi "kurang" dari spesifikasi. Terpakai = total fisik - tersedia, di mana tersedia = MemFree + Buffers + (Cached - Shmem) + KReclaimable/SReclaimable, dibatasi oleh MemAvailable (diambil yang lebih konservatif). Shmem/ashmem/tmpfs tidak lagi dihitung sebagai cache yang bisa dibuang, itu penyebab RAM terpakai tampil terlalu kecil. Baris baru: Tersedia, Cache bisa dibuang, Terbaca kernel, plus bar Swap/ZRAM. Bar RAM berubah kuning >=75% dan merah >=90%. Request `devinfo live` tidak lagi menumpuk (hasil lama tak menimpa yang baru). `devinfo live` kini juga mengeluarkan `mem_shmem_kb`, `mem_srec_kb`, `mem_krec_kb`, `mem_mapped_kb`.
- **Liquid Glass sungguhan** (toggle Tampilan, default aktif): elemen yang disentuh **membesar (zoom)** dengan lensa kaca dan kilau yang mengikuti jari; baris Status, baris opsi/fitur, semua tombol, pill, dan chip. Saat dilepas memantul seperti jelly. Pilihan yang baru dipilih (Mode layar, preset, dsb) melakukan "pop". Jempol switch melebar jadi lensa kaca saat ditekan dan memantul saat berpindah. Dock tab: label aktif/yang ditunjuk membesar, dock ikut membesar saat disentuh, dan pil kaca kini mengikuti jari dengan **pegas** (tertinggal, melaju, memantul, meregang sesuai kecepatan) bukan menempel kaku. Latar blob warna lembut yang bergerak pelan agar kaca terlihat membiaskan sesuatu. Hormati `prefers-reduced-motion`. Mematikan toggle mengembalikan tampilan lama.

## v2.6.0
- **Disable Thermal AGRESIF**: penyebab `vendor.thermal-hal-2-0.mtk` masih "running" = HAL itu dinyalakan ulang init lewat `ctl.interface_start` setiap system_server/powerhal memintanya. Sekarang: stop + ctl.stop + `kill -9` PID, watchdog 2 dtk (bukan 5) untuk service running **dan restarting**, sapu proses `*thermal*` yatim, dan kalau service hidup lagi -> **BLOCK** (binary HAL di-bind-mount stub `exit 0`, dilepas otomatis saat fitur dimatikan / uninstall). Lapis kernel: policy THERMAL MTK PPM dimatikan + trip passive/active zona SoC dinaikkan ke `TK_TRIP_C` (nilai asli disimpan & dikembalikan). Pengaman suhu tetap sama. Tombol baru **Paksa matikan sekarang** (`azenith-ai thermalkill now`); `thermalkill status` menampilkan PID/exe tiap service yang masih hidup + daftar BLOCK. Scan thermal_services kini ikut mengenali `*thermal-hal*` dan `thermal_space`.
- **RAM/ROM akurat**: satuan sekarang desimal (1 GB = 10^9 byte) seperti DevCheck/Pengaturan Android (sebelumnya GiB tapi ditulis GB: 8,06 GB tampil 7,5 GB). RAM tampil terpakai/total (%) + bebas, fallback MemFree+Buffers+Cached bila kernel tanpa MemAvailable. Baris baru "Terpakai (seperti Pengaturan)" = kapasitas nominal - ruang kosong /data. Parsing `df` memakai 5 kolom terakhir (tahan baris terbungkus). SoC MT6789 diberi label "Helio G99 / G100" (platform sama).
- WebUI: dock bawah dirombak gaya Hino Manager - pil kaca melayang, tab aktif pil putih, chip Telegram di bawahnya (tautan t.me diperbaiki: tanpa `@`).

## v2.5.0
- **Disable Thermal mandiri** (`azenith-ai thermalkill on|off|status`, switch di tab Kontrol): mematikan semua service init `*thermal*` yang running (dibaca dari `getprop init.svc.*`, mis. thermal_core, thermal_space, thermald, vendor.thermal-hal-2-0.mtk), menjaganya tetap mati (cek ulang tiap 5 dtk), tahan reboot (`THERMAL_KILL=1`). Sebelumnya thermal hanya disentuh selama game aktif lalu dikembalikan, jadi service tetap terlihat running saat dicek. Pengaman: zona kernel tidak disentuh; baterai>=45C / skin>=47C / SoC>=batas tier selama 10 dtk -> otomatis dikembalikan. Tombol Verifikasi menampilkan status tiap service.
- WebUI: tiap tab sekarang **bisa di-scroll sendiri** (sebelumnya item terakhir, mis. di Fitur, tertutup tab bar dan tak bisa digulir); ada ruang bawah di atas tab bar
- WebUI: banner diturunkan sedikit dan memakai **foto profil** logo AT (tiktok @azettech)

## v2.4.0
- WebUI: tab bar bawah sekarang bisa **digeser dengan jari** - tekan lalu geser, pil Liquid Glass mengikuti jari, halaman berganti saat digeser, tepi kiri/kanan otomatis menggulung bar (ketuk biasa tetap berfungsi)
- WebUI: kartu baru **Status Perangkat** di tab Status (di atas kartu Status): model/brand/kode device, SoC + CPU (cluster, core, frekuensi), GPU, RAM/swap, ROM penyimpanan + partisi data, Android/patch, **tipe ROM (Stock / AOSP / Port / GSI)** + nama ROM + alasan deteksi, bootloader/vboot/Treble/slot, SELinux, root manager, **kernel** (versi, nama/tag, build, compiler), baterai, layar
- CLI baru `azenith-ai devinfo [live]` (key=value) sebagai sumber data kartu itu; bagian `live` (RAM, suhu/baterai, frekuensi, uptime) di-refresh tiap 5 dtk hanya saat tab Status terbuka
- Klasifikasi ROM stock/AOSP/port adalah heuristik (skin vendor vs brand device, prop custom ROM, signing keys, kode device system vs vendor) - alasan & tingkat keyakinan ditampilkan

## v2.3.0
- Scan ROM (stock/GSI/custom) + ditampilkan di status & laporan kernel match
- `kernel apply` ditolak otomatis kalau hasil match terakhir bukan `VENDOR_LIKELY` (perlu `force` eksplisit)
- Upload kernel di WebUI: retry otomatis per-chunk + lanjutkan upload yang terputus (tidak perlu ulang dari 0) + verifikasi ukuran akhir
- Auto-update via `updateJson` (Magisk/KernelSU Manager cek `update.json` ini secara berkala)
- `customize.sh`: versi banner diambil otomatis dari `module.prop` (tidak lagi ketinggalan), referensi `action.sh` yang sudah dihapus dibuang dari daftar permission, `lib/kernel_match.sh` ditambahkan ke daftar itu (sebelumnya kelewatan)

## v2.1.0
- (lihat README "Catatan jujur" untuk riwayat sebelumnya)
