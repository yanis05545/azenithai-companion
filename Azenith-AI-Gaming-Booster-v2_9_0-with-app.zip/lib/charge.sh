#!/system/bin/sh
# =====================================================================
#  Azenith-AI v2 - lib/charge.sh : "Bypass Charging" NYATA (bukan toggle visual)
#
#  Tujuan: selama main sambil nge-charge, hentikan arus charging ASLI lewat
#  node sysfs charger kernel (bukan cuma mengubah tampilan di WebUI), supaya
#  baterai tidak terus-menerus di-charge penuh (panas + umur baterai) saat
#  daya cukup dipasok langsung dari charger.
#
#  KEJUJURAN: tidak semua device punya node kontrol charging yang kebuka di
#  sysfs (kadang disembunyikan di HAL/vendor proprietary). Kalau TIDAK ada
#  node yang bisa ditulis DAN terbukti mengubah status baterai asli (dibaca
#  balik dari power_supply/*/status), fitur ini menolak aktif dan bilang
#  TIDAK DIDUKUNG - tidak pernah berpura-pura "aktif" di WebUI kalau charging
#  sungguhan masih jalan.
#
#  Cara kerja:
#   1. chg_build_candidates()  - kumpulkan semua node charger yang ADA & bisa
#      ditulis di /sys/class/power_supply/*/ (urutan: enable-switch dulu,
#      lalu input_suspend, baru batasi arus ke 0 sebagai jalan terakhir)
#   2. chg_on() - coba tiap kandidat SATU PER SATU: tulis -> tunggu 2 dtk ->
#      baca ULANG status baterai asli. Dipakai hanya kalau status baterai
#      benar-benar berubah dari "Charging" walau charger tetap tersambung.
#   3. lib/chargeloop.sh - watchdog latar belakang: re-assert node (sebagian
#      charger IC mengembalikan nilainya tiap beberapa detik), auto-OFF kalau
#      charger dicabut (percuma diblok) atau baterai turun ke CHARGE_MIN_PCT
#      (anti over-discharge saat beban main berat).
#   4. Revert nilai asli (chg_restore_node) dipanggil di chg_off(), dan di
#      uninstall.sh / service.sh supaya TIDAK PERNAH meninggalkan device
#      dalam kondisi tidak bisa charge sama sekali.
# =====================================================================

CHG_BK="$DATADIR/chg_backup"     # path|nilai_asli (satu baris per node yang pernah ditulis)
CHG_NODE="$DATADIR/chg_node"     # path|method node yang SEDANG dipakai (enable|suspend|current)
CHG_PID="$RUNDIR/chg.pid"
CHG_CAND="$RUNDIR/chg_cand"

chg_setconf() { # chg_setconf KEY VAL
  if grep -q "^$1=" "$CONF" 2>/dev/null; then sed -i "s/^$1=[^ #]*/$1=$2/" "$CONF"
  else echo "$1=$2" >> "$CONF"; fi
}

# -------------------- deteksi direktori power_supply --------------------
chg_ps_dirs() { for cd_d in "$R"/sys/class/power_supply/*; do [ -d "$cd_d" ] && echo "$cd_d"; done; }

chg_bat_dir() {
  for cb_d in "$R/sys/class/power_supply/battery" "$R/sys/class/power_supply/Battery"; do
    [ -d "$cb_d" ] && { echo "$cb_d"; return 0; }
  done
  for cb_d in $(chg_ps_dirs); do
    case "$(dv_lc "$(dv_cat "$cb_d/type" 2>/dev/null)")" in battery) echo "$cb_d"; return 0 ;; esac
  done
  return 1
}

chg_plugged() { # 0 = ada charger (usb/ac/wireless/dc) online
  for cp_d in $(chg_ps_dirs); do
    case "$(dv_lc "$(dv_cat "$cp_d/type" 2>/dev/null)")" in
      usb|mains|wireless|dc)
        [ "$(dv_cat "$cp_d/online" 2>/dev/null)" = 1 ] && return 0 ;;
    esac
  done
  return 1
}

# -------------------- backup / tulis / pulihkan node --------------------
chg_write_node() { # chg_write_node PATH VAL  -> 0 kalau berhasil ditulis (TIDAK berarti sudah terbukti efeknya)
  cw_p=$1; cw_v=$2
  [ -w "$cw_p" ] || return 1
  grep -q "^$cw_p|" "$CHG_BK" 2>/dev/null || echo "$cw_p|$(dv_cat "$cw_p")" >> "$CHG_BK"
  { echo "$cw_v" > "$cw_p"; } 2>/dev/null || return 2
  return 0
}

chg_restore_node() {
  [ -s "$CHG_BK" ] || { : > "$CHG_BK"; return 0; }
  while IFS='|' read -r cr_p cr_v; do
    [ -n "$cr_p" ] && [ -e "$cr_p" ] && [ -n "$cr_v" ] && { echo "$cr_v" > "$cr_p"; } 2>/dev/null
  done < "$CHG_BK"
  : > "$CHG_BK"
}

# -------------------- kandidat node (prioritas: paling "bersih" dulu) --------------------
chg_build_candidates() {
  : > "$CHG_CAND"
  cc_add() { [ -w "$1" ] && echo "$1|$2|$3" >> "$CHG_CAND"; }
  cc_bat=$(chg_bat_dir)
  # 1) switch enable/disable charging langsung (paling umum: charging_enabled)
  for cc_leaf in charging_enabled batt_charging_enabled battery_charging_enabled charge_enabled charger_charging_enabled; do
    [ -n "$cc_bat" ] && cc_add "$cc_bat/$cc_leaf" enable 0
  done
  for cc_d in $(chg_ps_dirs); do
    [ "$cc_d" = "$cc_bat" ] && continue
    for cc_leaf in charging_enabled batt_charging_enabled battery_charging_enabled charge_enabled; do
      cc_add "$cc_d/$cc_leaf" enable 0
    done
  done
  # 2) suspend arus input (1 = suspend/stop) - umum di charger MTK/QCOM
  [ -n "$cc_bat" ] && cc_add "$cc_bat/input_suspend" suspend 1
  for cc_d in $(chg_ps_dirs); do
    [ "$cc_d" = "$cc_bat" ] && continue
    cc_add "$cc_d/input_suspend" suspend 1
  done
  # 3) jalan terakhir: batasi arus charge/input ke 0mA (nilai asli di-backup & dikembalikan)
  for cc_leaf in constant_charge_current_max input_current_limit current_max; do
    [ -n "$cc_bat" ] && cc_add "$cc_bat/$cc_leaf" current 0
  done
  for cc_d in $(chg_ps_dirs); do
    [ "$cc_d" = "$cc_bat" ] && continue
    for cc_leaf in constant_charge_current_max input_current_limit current_max; do
      cc_add "$cc_d/$cc_leaf" current 0
    done
  done
}

# -------------------- verifikasi NYATA (bukan asumsi) --------------------
chg_verify() { # 0 = status baterai sudah BUKAN "Charging" (charger tetap boleh tersambung)
  cv_bd=$(chg_bat_dir) || return 1
  case "$(dv_lc "$(dv_cat "$cv_bd/status" 2>/dev/null)")" in charging) return 1 ;; esac
  return 0
}

chg_cur_status() { cs_bd=$(chg_bat_dir) 2>/dev/null; dv_cat "$cs_bd/status" 2>/dev/null; }
chg_cur_level()  { cl_bd=$(chg_bat_dir) 2>/dev/null; dv_cat "$cl_bd/capacity" 2>/dev/null; }

# -------------------- on/off/status --------------------
chg_on() {
  load_conf
  if ! chg_plugged; then
    echo "DITOLAK: charger tidak terpasang - Bypass Charging cuma berguna selagi USB/charger tersambung."
    return 1
  fi
  chg_build_candidates
  if [ ! -s "$CHG_CAND" ]; then
    echo "DITOLAK: tidak ada node kontrol charging yang ketemu & bisa ditulis di semua /sys/class/power_supply/* milik device ini. Bypass Charging TIDAK didukung di sini - fitur sengaja tidak diaktifkan (tidak ada toggle visual palsu)."
    return 1
  fi
  : > "$CHG_BK"; cg_tries=0
  while IFS='|' read -r cg_p cg_m cg_v; do
    [ -n "$cg_p" ] || continue
    cg_tries=$((cg_tries + 1))
    chg_write_node "$cg_p" "$cg_v" || continue
    sleep 2
    if chg_verify; then
      echo "$cg_p|$cg_m" > "$CHG_NODE"
      chg_setconf CHARGE_BYPASS 1
      chg_loop_start
      log_msg "CHARGE: Bypass Charging AKTIF (node=$cg_p metode=$cg_m, percobaan ke-$cg_tries, status baterai sekarang '$(chg_cur_status)')"
      echo "Bypass Charging: AKTIF & TERVERIFIKASI NYATA (node=$cg_p, status baterai berubah jadi '$(chg_cur_status)' walau charger tetap tersambung - diperiksa ulang tiap ${CHARGE_TICK:-5}dtk, auto-mati kalau baterai <= ${CHARGE_MIN_PCT:-20}% atau charger dicabut)"
      chg_status
      return 0
    fi
    chg_restore_node; : > "$CHG_BK"
  done < "$CHG_CAND"
  echo "GAGAL: sudah dicoba $cg_tries node charger tapi status baterai TETAP 'Charging' di semuanya - charger IC device ini kemungkinan dikontrol lewat HAL proprietary yang tidak kebuka ke sysfs. Bypass Charging TIDAK diaktifkan (menolak melaporkan sukses palsu)."
  log_msg "CHARGE: Bypass Charging GAGAL diverifikasi setelah $cg_tries percobaan node"
  return 1
}

chg_off() {
  load_conf
  chg_loop_stop
  chg_restore_node
  chg_setconf CHARGE_BYPASS 0
  rm -f "$CHG_NODE"
  echo "Bypass Charging: MATI (node dikembalikan ke nilai asal, charging normal jalan lagi)"
  chg_status
}

chg_status() {
  load_conf
  cst_node=$(cat "$CHG_NODE" 2>/dev/null)
  echo "CHARGE_BYPASS=$CHARGE_BYPASS  node=${cst_node:--}  loop=$(chg_loop_alive && echo jalan || echo mati)"
  echo "baterai: level=$(chg_cur_level)%  status=$(chg_cur_status)  charger_terpasang=$(chg_plugged && echo ya || echo tidak)  batas_aman=${CHARGE_MIN_PCT:-20}%"
}

# -------------------- watchdog --------------------
chg_loop_alive() { cla_p=$(cat "$CHG_PID" 2>/dev/null); [ -n "$cla_p" ] && kill -0 "$cla_p" 2>/dev/null; }
chg_loop_start() {
  chg_loop_alive && return 0
  nohup sh "$MODDIR/lib/chargeloop.sh" >/dev/null 2>&1 &
}
chg_loop_stop() {
  cls_p=$(cat "$CHG_PID" 2>/dev/null)
  [ -n "$cls_p" ] && kill "$cls_p" 2>/dev/null
  rm -f "$CHG_PID"
}
