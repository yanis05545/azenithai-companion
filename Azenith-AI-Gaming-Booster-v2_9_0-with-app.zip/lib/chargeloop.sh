#!/system/bin/sh
# Azenith-AI - chargeloop.sh : watchdog Bypass Charging
#  - re-assert node (sebagian charger IC/HAL mengembalikan nilainya sendiri
#    tiap beberapa detik, jadi perlu ditulis ulang supaya tetap efektif)
#  - auto-OFF kalau charger dicabut (percuma diblok, biarkan charge normal)
#  - auto-OFF kalau baterai turun ke CHARGE_MIN_PCT (anti over-discharge saat
#    beban game berat lebih besar dari daya yang dipasok charger)
MODDIR=${0%/*}; MODDIR=${MODDIR%/lib}
export MODDIR
. "$MODDIR/common.sh"
load_conf
cg_p=$(cat "$CHG_PID" 2>/dev/null)
[ -n "$cg_p" ] && [ "$cg_p" != "$$" ] && kill -0 "$cg_p" 2>/dev/null && exit 0
echo $$ > "$CHG_PID"
trap 'rm -f "$CHG_PID"' EXIT
log_msg "CHARGE: watchdog Bypass Charging start pid=$$"
cg_i=0
while :; do
  [ $((cg_i % 6)) = 0 ] && load_conf
  [ "$CHARGE_BYPASS" = 1 ] || break
  [ -f "$MODDIR/disable" ] && break
  cg_line=$(cat "$CHG_NODE" 2>/dev/null)
  cg_path=${cg_line%%|*}; cg_m=${cg_line#*|}
  if [ -z "$cg_path" ] || [ ! -e "$cg_path" ]; then
    log_msg "CHARGE: node hilang ($cg_path) - watchdog berhenti"
    break
  fi
  if ! chg_plugged; then
    log_msg "CHARGE: charger dilepas -> Bypass Charging dimatikan otomatis"
    notify "Bypass Charging dimatikan otomatis: charger dilepas"
    chg_off >/dev/null 2>&1
    break
  fi
  cg_lv=$(chg_cur_level)
  case "$cg_lv" in ''|*[!0-9]*) cg_lv="" ;; esac
  if [ -n "$cg_lv" ] && [ "$cg_lv" -le "${CHARGE_MIN_PCT:-20}" ] 2>/dev/null; then
    log_msg "CHARGE: baterai turun ke ${cg_lv}% (batas ${CHARGE_MIN_PCT:-20}%) -> Bypass Charging dimatikan otomatis demi keamanan"
    notify "Bypass Charging dimatikan otomatis: baterai ${cg_lv}%"
    chg_off >/dev/null 2>&1
    break
  fi
  # re-assert nilai (sebagian kernel/HAL reset node ini sendiri tiap beberapa detik)
  cg_want=0; [ "$cg_m" = suspend ] && cg_want=1
  cg_cur=$(dv_cat "$cg_path" 2>/dev/null)
  [ "$cg_cur" = "$cg_want" ] || { echo "$cg_want" > "$cg_path"; } 2>/dev/null
  # kalau status kembali 'Charging' walau node sudah ditulis -> dianggap tidak
  # efektif lagi di node ini, matikan jujur daripada berpura-pura masih aktif
  if ! chg_verify; then
    cg_bad=$(( ${cg_bad:-0} + 1 ))
    if [ "$cg_bad" -ge 3 ]; then
      log_msg "CHARGE: node $cg_path tidak lagi efektif (status 'Charging' 3x berturut) -> Bypass Charging dimatikan otomatis, tidak dipaksakan"
      notify "Bypass Charging dimatikan: node charger sudah tidak efektif lagi di device ini"
      chg_off >/dev/null 2>&1
      break
    fi
  else
    cg_bad=0
  fi
  cg_i=$((cg_i + 1))
  sleep "${CHARGE_TICK:-5}"
done
log_msg "CHARGE: watchdog selesai"
