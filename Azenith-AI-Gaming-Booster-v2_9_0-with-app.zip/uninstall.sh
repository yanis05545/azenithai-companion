#!/system/bin/sh
# Azenith-AI v2 - uninstall.sh: kembalikan semua state lalu hapus data.
MODDIR=/data/adb/modules/azenith-ai
DATADIR=/data/adb/azenith-ai
if [ -f "$MODDIR/common.sh" ]; then
  . "$MODDIR/common.sh"
  load_conf 2>/dev/null
  cleanup_all 2>/dev/null
  tk_loop_stop 2>/dev/null; tk_restore_all 2>/dev/null   # lepas BLOCK + hidupkan lagi service thermal
  chg_loop_stop 2>/dev/null; chg_restore_node 2>/dev/null  # WAJIB: jangan sampai device tidak bisa charge lagi setelah uninstall
fi
# v2 tidak memakai resetprop -p (persisten). Hapus sisa v1 kalau ada.
for p in sys.thermal.engine.disable persist.sys.ui.hw persist.sys.input.boost vendor.mtk.fpsgo.enable \
         dalvik.vm.heapgrowthlimit debug.hwui.renderer; do
  case "$p" in
    persist.*|dalvik.*|debug.hwui.*) : ;;   # jangan hapus prop sistem asli secara membabi buta
    *) resetprop --delete "$p" 2>/dev/null ;;
  esac
done
rm -rf "$DATADIR"
exit 0
