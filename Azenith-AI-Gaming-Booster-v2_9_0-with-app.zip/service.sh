#!/system/bin/sh
# Azenith-AI v2 - service.sh (late_start): hanya meluncurkan supervisor.
MODDIR=${0%/*}
[ -f "$MODDIR/disable" ] && exit 0
# tunggu boot selesai supaya dumpsys/ps stabil
n=0
while [ "$(getprop sys.boot_completed)" != 1 ] && [ "$n" -lt 180 ]; do sleep 2; n=$((n + 2)); done
sleep 5
mkdir -p /data/adb/azenith-ai/run
rm -f /data/adb/azenith-ai/run/stop
sh "$MODDIR/lib/supervisor.sh" >/dev/null 2>&1 &
# Disable Thermal: fitur inti PERMANEN, otomatis tiap boot - bukan tergantung toggle user.
# Paksa THERMAL_KILL=1 di conf (jaga-jaga kalau ada yang mengubahnya manual/conf lama),
# lepas kunci Bypass Thermal, lalu jalankan penjaganya tanpa syarat.
TK_CONF=/data/adb/azenith-ai/azenith-ai.conf
if [ -f "$TK_CONF" ]; then
  if grep -q '^THERMAL_KILL=' "$TK_CONF"; then
    sed -i 's/^THERMAL_KILL=.*/THERMAL_KILL=1/' "$TK_CONF"
  else
    echo 'THERMAL_KILL=1' >> "$TK_CONF"
  fi
  sed -i 's/^BYPASS_THERMAL=1/BYPASS_THERMAL=0/' "$TK_CONF" 2>/dev/null
fi
nohup sh "$MODDIR/lib/tkloop.sh" >/dev/null 2>&1 &
# Bypass Charging tahan reboot: kalau CHARGE_BYPASS=1 di conf, jalankan watchdog-nya lagi
# (node charger non-persisten, hilang tiap reboot - harus ditulis ulang + diverifikasi lagi)
if grep -q '^CHARGE_BYPASS=1' /data/adb/azenith-ai/azenith-ai.conf 2>/dev/null; then
  nohup sh "$MODDIR/lib/chargeloop.sh" >/dev/null 2>&1 &
fi
# Companion App: pasang / upgrade otomatis dari app/AzenithAI-Companion.apk (di-background supaya tidak menahan boot)
sh "$MODDIR/lib/app_install.sh" >/dev/null 2>&1 &
exit 0
