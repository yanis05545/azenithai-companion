# Azenith-AI Gaming Booster v2.9.0

## Baru: Companion App (APK di dalam module)

Module ini membawa aplikasi sendiri (`app/AzenithAI-Companion.apk`, package `com.azenithtech.azenithai`).
Tampilannya sama persis dengan WebUI karena app memuat `webroot/` module yang terpasang;
semua fitur tetap dijalankan module (`azenith-ai` CLI + daemon) dan app menyalurkan perintah
lewat shell root. Dipasang otomatis saat boot (`lib/app_install.sh`), dibuka juga dari tombol
**Action** di Manager. Saat pertama dibuka, Manager akan minta izin root untuk app ini - izinkan.
Source APK ada di zip terpisah (`AzenithAI-Companion-src.zip`).


## Baru: Bypass Charging (nyata, bukan visual)

Tab Kontrol > **Bypass Charging**, CLI `azenith-ai charge on|off|status`. Mencari
node kontrol charger ASLI di `/sys/class/power_supply/*/*` (`charging_enabled`
dan sejenisnya -> `input_suspend` -> batas arus ke 0 sebagai jalan terakhir),
menulisnya, lalu **membaca ulang status baterai** untuk membuktikan status
benar-benar berubah dari `Charging` walau charger tetap tersambung. Kalau
tidak ada node yang terbukti berefek di device itu, fitur **menolak aktif**
dan bilang tidak didukung — tidak ada mode "pura-pura aktif". Watchdog latar
belakang menjaga node tetap tertulis, dan otomatis mati kalau charger
dicabut, baterai turun ke `CHARGE_MIN_PCT` (default 20%), atau node ternyata
berhenti efektif. Lihat "Catatan jujur" soal device yang charger IC-nya
dikontrol lewat HAL proprietary (tidak kebuka ke sysfs).

## Baru: kestabilan ping/jaringan

`FEAT_NETWORK` sekarang juga mematikan optimisasi daya WiFi + throttle scan
background selama main (sumber umum ping melonjak), menambahkan game ke
whitelist Doze/App Standby, dan `tcp_fastopen=3`. Nyalakan `NET_PING_LOG` (tab
Status, toggle "Monitor kestabilan ping") untuk melihat avg/jitter/packet-loss
NYATA dari `ping` di kartu **Jaringan**.

## Baru: Bypass Thermal

Tab Kontrol > **Bypass Thermal**. Beda dari "Disable Thermal": tidak membunuh
service apa pun, cuma memaksa `THERMAL_MODE=hard` lewat jalur `lib/thermal.sh`
yang sudah ada — jadi service thermal yang boros baterai (daemon polling)
dihentikan, dan node vendor pembatas performa/trip passive-active dimatikan,
tapi pengaman suhu normal (baca suhu asli, auto-turunkan ke `auto` kalau
kepanasan) tetap jalan apa adanya. **Saling kunci** dengan Disable Thermal:
Disable Thermal tidak bisa dinyalakan selama Bypass aktif (`azenith-ai
thermalkill on` akan `DITOLAK`), dan menyalakan Bypass saat Disable Thermal
sedang ON otomatis mematikan Disable Thermal dulu. CLI: `azenith-ai bypass
on|off|status`.


Module root universal (Magisk 20.4+ / KernelSU / APatch), Android 9–15.
Snapdragon, MediaTek, Exynos, Tensor, Unisoc.

## Baru di v2.5.0

- **Disable Thermal mandiri** (switch di tab Kontrol / `azenith-ai thermalkill on|off|status`):
  menghentikan semua service init bernama `*thermal*` yang sedang running dan menjaganya mati
  (loop 5 dtk, tahan reboot). Verifikasi sendiri: `getprop | grep init.svc | grep thermal`
  harus menunjukkan `stopped`. Zona suhu kernel sengaja tidak disentuh agar pengaman suhu
  tetap bisa membaca suhu asli; saat panas terus-menerus fitur mati sendiri. Catatan jujur:
  ini mematikan throttling dari userspace/HAL, bukan throttle di dalam kernel/firmware (mis.
  proteksi baterai/charger atau thermal MCU MTK), dan belum diuji di device fisik.
- Tiap tab bisa di-scroll sendiri, banner turun sedikit + foto profil.

## Baru di v2.4.0

- **Tab bar bisa digeser dengan jari** (pil kaca mengikuti jari, halaman ikut berganti).
- **Kartu "Status Perangkat"** di tab Status, di atas kartu Status: device, SoC/CPU/GPU, RAM & ROM
  penyimpanan, Android, tipe ROM (stock/AOSP/port/GSI), kernel yang dipakai, root, baterai, layar.
  Data dari `azenith-ai devinfo` (getprop, `/proc`, `/sys`, `df`). Tipe ROM adalah **heuristik**
  (lihat alasan yang ditampilkan di bawahnya); ROM port yang propnya sudah dirapikan porter bisa
  terbaca sebagai stock/AOSP. Nama marketing SoC hanya untuk beberapa model yang pasti; selain itu
  ditampilkan apa adanya dari prop. Belum diuji di device fisik.

## Baru di v2.3.0

- **Scan ROM (stock/GSI/custom/porting).** `lib/scan.sh` sekarang mendeteksi "keluarga" ROM
  device lewat sinyal struktural Android sendiri (bukan daftar nama ROM yang akan selalu
  ketinggalan): tanda tangan Treble GSI (`ro.product.system.brand` beda dari brand device
  fisik), signing keys (`release-keys` vs `test-keys`/`dev-keys`), dan build type
  (`user` vs `userdebug`/`eng`). Hasilnya (`ROM_FAMILY`: `stock`/`gsi`/`custom`/`unknown`)
  tampil di `azenith-ai status`, `azenith-ai report`, dan kartu Status WebUI — **murni
  diagnostik**, tidak ada fitur yang di-gate olehnya, karena semua node tetap divalidasi
  langsung ke sysfs device saat itu juga (lihat "Catatan jujur"). Gunanya: kalau sebuah fitur
  skip di ROM tertentu, kamu bisa langsung lihat kenapa (mis. GSI yang memang biasanya tidak
  membawa driver vendor penuh) alih-alih menduga-duga.
- **`kernel apply` kini menolak match yang tidak meyakinkan secara default.** Sebelumnya
  "Terapkan hasil" di WebUI/CLI langsung menerapkan node yang cocok nama meski berkas yang
  diupload diklasifikasi bukan `VENDOR_LIKELY` (mis. ternyata boot Image generik). Sekarang
  itu ditolak dengan pesan jelas kecuali dipaksa (`azenith-ai kernel apply force` / konfirmasi
  di WebUI) — audisi A/B tetap jalan seperti biasa setelahnya baik dipaksa atau tidak, ini
  hanya mengurangi node sampah yang masuk antrian audisi dari awal.
- **Upload kernel di WebUI lebih tahan banting di device low-end.** Tiap potongan (chunk)
  base64 sekarang dicoba ulang otomatis (sampai 4x, dengan jeda) sebelum menyerah, progres
  upload disimpan dan **dilanjutkan dari byte terakhir yang benar-benar tersimpan di
  device** (bukan dari 0 lagi) kalau gagal di tengah jalan atau WebUI sempat
  ditutup/reload, dan ukuran akhir berkas diverifikasi ke device sebelum dicocokkan (menangkap
  upload yang terpotong diam-diam).
- **Auto-update.** `module.prop` punya `updateJson` yang mengarah ke `update.json` — Magisk
  Manager / KernelSU Manager / APatch Manager akan mengecek berkas itu secara berkala dan
  menawarkan update sendiri, tidak perlu lagi dipantau manual. Lihat bagian "Auto-update"
  di bawah untuk cara menghubungkannya ke repo kamu sendiri (perlu di-host sekali).
- **Bersih-bersih kosmetik/dead code.** Banner versi di `customize.sh` sekarang dibaca
  langsung dari `module.prop` (tidak bisa lagi ketinggalan versi seperti sebelumnya),
  referensi ke `action.sh` yang sudah dihapus dibuang dari daftar permission, dan
  `lib/kernel_match.sh` (sebelumnya kelewatan) ditambahkan ke daftar itu supaya benar-benar
  executable setelah instalasi fresh.

## Baru di v2.2.0

- **Cocokkan kernel (WebUI).** Kartu baru "Cocokkan kernel": upload berkas kernel/driver
  (boot `Image`, `vendor_dlkm.img`, atau satu `.ko`) langsung dari HP lewat WebUI (tanpa
  adb/PC). Berkas dikirim ke device lewat `ksu.exec` (base64 per-chunk, tanpa transfer
  file native — WebUI KernelSU/APatch memang tidak punya API upload berkas, jadi dipakai
  jalur exec yang sudah ada), lalu `azenith-ai kernel match <berkas>` mengekstrak semua
  string identifier dari berkas itu dan mencocokkannya dengan nama node di
  `fpsgo_profile.conf` + node "disc" hasil scan. Hasilnya **mengklasifikasi berkasnya
  sendiri** (vendor driver yang relevan vs boot Image GKI generik yang nyaris pasti tidak
  mengandung driver FPSGO/gpufreq sama sekali — ini yang paling sering salah duga, jadi
  laporan bilang terus terang kalau berkas yang diupload ternyata tidak relevan, bukan
  pura-pura mencocokkan). Node yang cocok bisa diterapkan sebagai profil aktif
  (`azenith-ai kernel apply`, ada backup + `azenith-ai kernel revert`). Nama cocok di binary
  **tetap bukan jaminan semantik nilainya sama** — audisi A/B per game tetap satu-satunya
  pengaman sesungguhnya, fitur ini hanya menyaring node yang jelas tidak relevan dari
  grup "disc" yang paling berisiko (lihat catatan jujur di bawah).
  CLI: `azenith-ai kernel match <berkas>` · `kernel apply` · `kernel revert`.
- **Proteksi panas mode hard diperketat.** `THERMAL_MODE=hard` mematikan lebih banyak
  node throttle vendor, jadi pengaman software sekarang ikut lebih ketat khusus di mode
  ini (bukan pakai ambang yang sama dengan auto/soft): jendela konfirmasi panas dipangkas
  dari 20 ke 8 detik (`HARD_SAFE_HOT_SECONDS`), cek suhu 2x lebih sering (`HARD_MON_SEC`),
  dan ada jalur darurat terpisah: kalau suhu melewati batas tier + 5°C
  (`HARD_EMERGENCY_MARGIN_C`), boost dimatikan **seketika** tanpa menunggu ambang waktu
  sama sekali. Setelah safety trip di mode hard, `THERMAL_MODE` otomatis diturunkan ke
  `auto` (`HARD_DEMOTE_AFTER_TRIP=1`) — mode hard harus dipilih ulang secara sadar, tidak
  otomatis dicoba lagi dengan ambang yang sama persis begitu cooldown habis.
- **Anti-sawtooth level FPS.** FPS Sustain Engine sekarang mendeteksi level CPU/GPU yang
  naik-turun cepat bolak-balik (pola gergaji) dalam jendela `SAWTOOTH_WINDOW_SEC` (default
  45 dtk); kalau terjadi `SAWTOOTH_FLAPS` (default 3) kali gantian arah, level dikunci di
  posisi terakhir selama `SAWTOOTH_LOCK_SEC` (default 60 dtk) alih-alih terus berosilasi.
  Pengaman thermal (batas suhu) tidak terpengaruh kunci ini dan tetap selalu jalan.

## Install
Flash zip lewat Manager (Magisk/KernelSU/APatch) → reboot. Setelah boot:
`su -c azenith-ai status`, lalu `su -c azenith-ai selftest` (uji
apply→verifikasi→revert di device kamu sendiri).

Di Manager, modul ini tampil dengan **2 tombol** (sejak v2.8.0, `action.sh`
dikembalikan):
- **Action** — jalankan sekali tap: reassert Disable Thermal + restart daemon
  tuning + tampilkan ringkasan status ("terapkan ulang sekarang").
- **WebUI** (`webroot/`) — dashboard lengkap (Status, Kontrol, Fitur, Game,
  Kernel, Alat, Tampilan). Disable Thermal **tidak ada** di WebUI sebagai
  toggle — fitur inti permanen, otomatis aktif sejak boot (lihat bagian
  "Disable Thermal" di tab Status).

KernelSU Manager & APatch Manager bisa membuat **ikon shortcut di homescreen**
langsung ke WebUI modul ini (buka WebUI dari Manager → menu titik tiga →
"Buat shortcut" / "Add to home screen"). Magisk 28+ juga menampilkan WebUI di
Manager-nya sendiri, tapi tidak punya fitur shortcut homescreen bawaan - bisa
disiasati pakai app WebUI pihak ketiga (mis. MMRL).

## Apa yang berubah dari v1 (sesuai daftar kekurangan)

| # | Kekurangan v1 | Perbaikan v2 |
|---|---|---|
| 1 | Path sysfs tebakan generik | `lib/scan.sh` memindai /sys, /proc, getprop device. CPU lewat `cpufreq/policy*` (bobot per-cluster), GPU lewat devfreq (Adreno/Mali/PowerVR/Unisoc) atau MTK GED atau Exynos `/sys/kernel/gpu`. Node yang tidak ada = fitur di-skip. Hasil di `/data/adb/azenith-ai/scan/` + `scan_report.txt` |
| 2 | Thermal inject gagal di device modern | Strategi bertingkat dari hasil scan (lihat bagian Thermal), klasifikasi zona SoC/baterai/skin, tier flagship/high/mid/low, batas suhu per-tier |
| 3 | `detect_true_fps` rapuh | Diganti **FPS Sustain Engine** berbasis FPSGO (lihat bagian FPS) |
| 4 | Polling dumpsys berat | Pra-filter `ps`, pantau game via `/proc/<pid>`, dumpsys hanya bila perlu + timeout, supervisor, single-instance |
| 5 | Baca tombol volume | Device input dicari lewat `getevent -pl` (yang benar-benar punya KEY_VOLUME*), jendela 8 detik |
| 6 | Tanpa UI | WebUI (`webroot/`) + tombol Action + CLI lengkap. App Kotlin native **tidak** dibuat (butuh Android SDK untuk build) |
| 7 | Belum diuji | `azenith-ai selftest` + test kit di sysfs tiruan (lihat Pengujian; v2.1 menambah `e2e_fpsgo.sh` + kernel FPSGO tiruan `fakefpsgo.py`) |

### Bug v1 yang ikut ditemukan & diperbaiki
- `update-binary` v1 hanya meng-extract ke /tmp dan **tidak memasang module**. Sekarang stub standar + `customize.sh`.
- Semua tweak diterapkan sekali saat boot (freq terkunci max 24/7), tidak pernah diterapkan ulang untuk game berikutnya. Sekarang apply saat game mulai, revert saat selesai.
- Baca "suhu asli" setelah inject → pengaman bisa buta. Sekarang pakai probe + sensor baterai/skin.
- Restore scheduler menulis string `[none] kyber ...` (gagal diam-diam); backup disimpan lintas boot; key backup bertabrakan antar-policy; urutan restore min/max.
- `resetprop -p` (persisten) untuk heap/renderer tanpa revert; prop `debug.sf.*` diset saat runtime (tidak berefek, hanya dibaca saat SF start) → sekarang di post-fs-data.
- `chrt -f` SCHED_FIFO pada seluruh proses game, `taskset` ke semua core (no-op), `stop logd`, `ping` tanpa batas ke file log, `cmd ufw` (tidak terverifikasi) → dibuang/diganti.
- Marker `last_boot_ok` → self-disable palsu bila reboot <2 menit. Sekarang boot counter (3 boot tak sehat berturut-turut).
- FPSGO **dimatikan** di v1 (berlawanan dengan tujuan FPS); sekarang dijaga aktif.

## Thermal (`THERMAL_MODE`)
- `off` tidak menyentuh thermal. `soft`: stop daemon thermal userspace (allow-list: thermal-engine, thermald, thermal_manager, thermalloadalgod…; HAL tidak disentuh), prop bergaya `disable…thermal` bernilai 0 → 1, `cmd thermalservice override-status`.
- `auto` (default): soft + `emul_temp` bila kernel mendukung **dan terbukti efektif**, kalau tidak `mode=disabled` pada zona kelas SoC.
- `hard`: auto + node vendor penonaktif throttle yang ada di device (Adreno `throttling`/`thermal_pwrlevel`, `msm_thermal`, MTK `gpufreq_limited_thermal_ignore`) + opsional `TRIP_RAISE_C` (trip passive saja, bukan critical).
- Pengaman: suhu asli dibaca lewat probe; baterai 43°C, skin 46°C, SoC per-tier (flagship 92 / high 88 / mid 85 / low 80) selama ≥20 dtk → semua direvert + cooldown 180 dtk. Kalau suhu SoC tidak bisa dibaca setelah apply, perubahan zona dibatalkan. Proteksi hardware/firmware (critical shutdown) tidak disentuh.

## FPS Sustain Engine
- Level boost 0–5 = lantai frekuensi CPU (bobot per-cluster) + GPU + uclamp top-app. Preset `auto` memilih cap/start sesuai tier.
- Sumber FPS (otomatis, di-demote bila gagal): `fpsgo_status` (MTK) → `dumpsys SurfaceFlinger --latency` per-layer game → `sde measured_fps` → `fb0 measured_fps`.
- FPS < 90% plafon (nilai tertinggi 20 sampel terakhir, bukan Hz layar) 2× berturut → level naik; stabil 15 sampel → turun 1 level; level yang terbukti perlu "dipelajari". Hangat → cap level 2.
- MediaTek: FPSGO dijaga aktif + `fpsgo_profile.conf` (tabel node, hanya node yang ada). Non-MediaTek tidak punya FPSGO; engine yang sama jalan dengan backend generic (cpufreq/devfreq/uclamp).

## FPSGO v2.1: node banyak + efek ke FPS dibuktikan (bukan klaim)
**Node.** `fpsgo_profile.conf` kini katalog 13 node berformat `nama|nilai|kelas|grup` (core, uclamp, rescue, ultra,
sched, margin, ceiling, fbtthermal) + grup `disc`: semua node biner (0/1) bernama `*rescue*`/`*boost*`/`*ultra*` yang
ditemukan di device kamu (tanpa kata debug/trace/limit/thermal/force/disable/...). Hanya node yang ADA, rw, dan bernilai
SATU angka yang disentuh. Daftar + klasifikasi tiap node device: `azenith-ai fpsgo nodes` (`scan/fpsgo_candidates.txt`).
Kelas `aggr` hanya di preset extreme / `THERMAL_MODE=hard`; `thermal` hanya di `hard`.

**Efek ke FPS (audisi A/B per game).** Saat game pertama kali dimainkan: warmup (loading diabaikan) -> ukur baseline ->
terapkan satu grup -> buang beberapa sampel -> ukur lagi. FPS turun >= `FPSGO_AB_REG_PCT` (3%) atau jank naik >= 15 poin
-> grup langsung dikembalikan ke nilai awal. Selain itu dipertahankan (label MEMBANTU bila naik >= 2%, NETRAL bila tidak
terukur). Hasil disimpan per game di `learn/<paket>.fpsgo` (berlaku 14 hari, kernel sama); sesi berikutnya langsung
memakai grup yang terbukti dan tidak menguji ulang. Selama audisi level CPU/GPU dibekukan supaya ukuran adil; audisi
batal bila suhu hangat atau sumber FPS hilang. Bukti: `azenith-ai fpsgo`, `fpsgo_effect.log`, `azenith-ai report`.

**Sumber FPS dari direktori sistem + data game.** Saat game mulai, daemon mengambil pid + semua tid game dari
`/proc/<pid>/task`, lalu membaca file di direktori FPSGO/perfmgr yang memuat pid/tid itu dan berisi fps. Format kolom
(`currentFPS`, `cur_fps`, `tid=.. fps=..`) dideteksi dari isi file (`lib/fpsgo_parse.awk`), dan baris difilter ke game
(bukan maksimum semua proses). Diagnosis kolom yang terdeteksi tercatat di log (`H: sumber FPS ...`).
`azenith-ai fpsgo reset [paket]` menghapus hasil uji.

## CLI
`azenith-ai status|on|off|auto|toggle|scan|report|selftest|doctor|preset|game add/del/list|set KEY NILAI|fps|fpsgo [nodes|reset]|kernel match <berkas>/apply [force]/revert|thermalkill on/off/now/status|bypass on/off/status|charge on/off/status|log|start|stop|restart|enable`
Jika `azenith-ai` tidak ada di PATH: `sh /data/adb/modules/azenith-ai/system/bin/azenith-ai …`

## Auto-update
Manager (Magisk/KernelSU/APatch) mengecek `updateJson` di `module.prop` secara berkala dan
menawarkan update sendiri kalau `versionCode` di sana lebih baru dari yang terpasang —
**tidak ada komponen di dalam module yang melakukan ini**, murni fitur bawaan Manager yang
butuh satu berkas `update.json` ter-host di URL stabil. Supaya ini aktif untuk rilismu sendiri:

1. Ganti `GANTI_USER_GITHUB/GANTI_REPO` di `module.prop` (field `updateJson`) dan di
   `update.json` dengan username/nama repo GitHub-mu sendiri.
2. Tiap rilis baru: naikkan `version`/`versionCode` di `module.prop` **dan** `update.json`
   (keduanya harus sama persis), upload zip rilis ke GitHub Releases dengan nama persis
   seperti di `zipUrl`, lalu push `update.json` + `CHANGELOG.md` ke branch `main`.
3. Tidak pakai GitHub? Host `update.json` di mana saja yang bisa diakses lewat HTTPS tanpa
   login (GitLab raw, Codeberg, Pages pribadi, dst) dan arahkan `updateJson` ke situ — formatnya
   JSON biasa (`version`, `versionCode`, `zipUrl`, `changelog`), tidak harus GitHub.

Tanpa langkah 1 di atas, `updateJson` menunjuk ke repo placeholder yang tidak ada —
Manager akan gagal diam-diam saat mengecek update (tidak merusak apa pun, cuma tidak akan
pernah menemukan update) sampai kamu isi dengan repo milikmu.

## Safe mode & bootloop
Tahan Volume UP di 8 detik pertama boot = daemon idle total; Volume DOWN = preset cool, thermal off.
Sebagian device memakai Vol DOWN untuk Magisk Safe Mode (itu menonaktifkan semua module).
3 boot berturut-turut tak sehat → module self-disable; `azenith-ai enable` untuk menghidupkan lagi.
Darurat: `adb shell rm -rf /data/adb/modules/azenith-ai`.

## Catatan jujur
- **Bypass Charging tidak dijamin didukung di semua device**: kalau charger IC device dikontrol penuh lewat HAL proprietary vendor (tidak ada node `charging_enabled`/`input_suspend`/`*current_max*` yang kebuka & terbukti berefek di `/sys/class/power_supply/*`), fitur ini jujur menolak aktif (lihat status baterai tetap `Charging` di output `azenith-ai charge on`) — bukan bug yang "bisa diperbaiki", itu memang tidak terbuka dari sisi root/sysfs di device itu.
- Belum diuji di hardware fisik. Logika diuji di sysfs/proses tiruan (5 profil SoC). Perilaku kernel asli (node ditolak, dibulatkan, di-override HAL vendor) hanya bisa dipastikan lewat `azenith-ai selftest` di device.
- **Tidak ada spesifikasi resmi node FPSGO dari MediaTek** — ini bukan sesuatu yang bisa "diperbaiki jadi resmi" di versi mana pun, MTK memang tidak menerbitkannya ke publik. Nama node katalog berasal dari ingatan atas driver MTK FPSGO v1-v3 (reverse-engineered, bukan dari dokumentasi resmi). Yang bisa (dan sudah) dilakukan untuk membuat ini **sejujur mungkin tanpa berpura-pura resmi**:
  1. "Cocokkan kernel" (WebUI/`azenith-ai kernel match`) mengecek nama node terhadap berkas kernel/driver device kamu sendiri sebelum dipakai, dan sejak v2.3 `kernel apply` **menolak otomatis** kalau hasilnya bukan diklasifikasi `VENDOR_LIKELY` (perlu `force` eksplisit kalau tetap mau coba) — lihat "Baru di v2.3.0".
  2. Nama simbol cocok di binary **tetap bukan jaminan semantik nilainya sama persis** — ini batas yang tidak bisa dihilangkan dengan reverse-engineering sebaik apa pun, jadi pengaman sesungguhnya tetap uji A/B per game: tiap grup node diterapkan lalu FPS **diukur langsung dari sistem**, grup yang terbukti menurunkan FPS otomatis dibuang dan tidak dicoba lagi (kecuali kernel berubah). Ini satu-satunya cara untuk benar-benar tahu sebuah node berguna di device tertentu tanpa dokumentasi resmi.
  - Uji A/B mengukur FPS rata-rata dan jank pada jendela pendek; perubahan kecil (<3%) tidak terdeteksi, dan game yang di-cap FPS-nya tidak akan menunjukkan gain (hasil NETRAL, bukan gagal).
- Grup "disc" (node biner yang namanya cuma cocok pola `*rescue*`/`*boost*`/`*ultra*`) paling berisiko karena bukan dari katalog bernama; "Cocokkan kernel" + uji A/B adalah dua lapis pengaman untuk grup ini, bukan jaminan mutlak.
- **Soal dukungan "semua SoC":** FPSGO itu sendiri cuma ada di MediaTek — bukan keterbatasan Azenith-AI, itu fakta hardware/kernel (Snapdragon/Exynos/Tensor/Unisoc tidak punya FPSGO sama sekali). Yang membuat Azenith-AI tetap "universal" bukan memaksakan FPSGO ke semua SoC, tapi FPS Sustain Engine (`lib/fps.sh`) punya dua backend: FPSGO + tuning node (MediaTek, lewat `lib/fpsgo.sh`) ATAU lantai `cpufreq`/`devfreq`/`uclamp` generik (`perf_set_level` di `lib/perf.sh`, jalan di SEMUA vendor karena itu API kernel Linux standar, bukan API vendor) — device non-MTK otomatis dapat backend generik ini, bukan fallback yang "kurang teruji", tapi jalur utama yang sama dipakai semua tier sejak awal (hanya tanpa lapisan tuning node FPSGO di atasnya, karena memang tidak ada yang bisa dituning).
- **Soal dukungan "semua ROM":** sejak v2.3 ada scan ROM (lihat "Baru di v2.3.0") yang mendeteksi stock/GSI/custom lewat tanda tangan Treble + signing keys + build type, murni untuk diagnostik di status/laporan. Tidak ada fitur yang digerbang oleh hasil scan ini karena semua node sudah divalidasi langsung ke sysfs device saat itu juga (prinsip di atas) — jadi "support" di sini bukan daftar ROM yang dites satu-satu, tapi device apa pun yang memberi node sysfs yang bisa dibaca & ditulis akan otomatis dipakai, ROM apa pun itu. Pengecualian nyata: GSI/porting kadang menghapus atau tidak menyertakan driver vendor (termasuk FPSGO) sama sekali di kernelnya — kalau itu terjadi, bukan bug Azenith-AI, node-nya memang tidak ada di device itu (fitur terkait otomatis di-skip, bukan dipaksakan).
- Parser FPS diuji pada tabel (kolom tid/pid), kv (`tid=.. fps=..`, `tid: .. cur_fps: ..`) dan file berisi proses lain; format asli device tetap hanya bisa dipastikan lewat `azenith-ai fpsgo` saat game berjalan. Bila gagal, engine pindah sumber, lalu mode statis dan mencatat ke log.
- Mematikan thermal tetap berisiko panas berlebih; mulai dari `THERMAL_MODE=soft` bila ragu.
- Upload berkas kernel di WebUI (v2.3: retry + resume + verifikasi ukuran, lihat "Baru di v2.3.0") tetap lewat `ksu.exec` per-chunk, bukan transfer file native — di device sangat lambat/RAM kecil ini masih bisa makan waktu beberapa menit untuk berkas besar meski sudah tidak lagi gagal total di tengah jalan. Upload `.ko` tunggal (bukan image penuh) kalau device low-end.
