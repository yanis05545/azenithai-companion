Taruh APK Companion App di folder ini dengan nama persis:

    AzenithAI-Companion.apk

Lalu flash ulang zip module (atau reboot kalau module sudah terpasang dan
APK ditaruh langsung di /data/adb/modules/azenith-ai/app/).
Package name: com.azenithtech.azenithai
Cara build APK + otomatis memasukkannya ke zip ini: lihat README di zip source APK
(tools/pack-module.sh).
