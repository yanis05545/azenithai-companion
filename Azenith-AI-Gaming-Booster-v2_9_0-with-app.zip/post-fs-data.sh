#!/system/bin/sh
# =====================================================================
#  Azenith-AI v2 - post-fs-data.sh   (paling awal; TIDAK ada tweak berat)
#   1. Boot counter: +1 tiap boot. Direset ke 0 oleh daemon setelah boot terbukti
#      sehat (boot_completed + BOOT_OK_DELAY detik). >= BOOT_FAIL_LIMIT berarti
#      beberapa boot berturut-turut tidak sempat sehat -> module self-disable.
#      (v1 memakai marker yang hilang kalau user reboot < 2 menit -> disable palsu)
#   2. Bersihkan state kadaluarsa (backup lama berbahaya setelah reboot).
#   3. Prop SurfaceFlinger (harus sebelum SF start).
#   4. Jalankan safe_trigger.sh (baca tombol volume) di background.
# =====================================================================
MODDIR=${0%/*}
export MODDIR
DATADIR=${TX_DATA:-/data/adb/azenith-ai}
mkdir -p "$DATADIR/backup" "$DATADIR/run" "$DATADIR/scan"

# state run-time dari boot sebelumnya sudah tidak valid
rm -rf "$DATADIR/run" "$DATADIR/backup"
mkdir -p "$DATADIR/run" "$DATADIR/backup"
: > "$DATADIR/applied_stack"; : > "$DATADIR/props_stack"; : > "$DATADIR/svc_stack"

. "$MODDIR/common.sh"
load_conf
log_rotate

n=$(cat "$DATADIR/boot_count" 2>/dev/null); n=${n:-0}
case "$n" in *[!0-9]*) n=0 ;; esac
n=$((n + 1)); echo "$n" > "$DATADIR/boot_count"
log_msg "BOOT: post-fs-data, boot_count=$n (batas $BOOT_FAIL_LIMIT)"

if [ "$n" -ge "$BOOT_FAIL_LIMIT" ]; then
  touch "$MODDIR/disable"
  echo "$(date '+%Y-%m-%d %H:%M:%S') SELF-DISABLED: $n boot berturut-turut tanpa boot sehat" >> "$DATADIR/bootloop_history.log"
  log_msg "BOOT: SELF-DISABLE (boot_count=$n). Jalankan 'azenith-ai enable' setelah boot normal."
  echo 0 > "$DATADIR/boot_count"
  exit 0
fi

sf_boot_props
sh "$MODDIR/safe_trigger.sh" >> "$LOG" 2>&1 &
exit 0
