#!/system/bin/sh
# Azenith-AI v2 - customize.sh (di-source oleh installer Magisk / KernelSU / APatch)
SKIPUNZIP=0
TXVER=$(sed -n 's/^version=//p' "$MODPATH/module.prop" 2>/dev/null)
ui_print "*********************************************"
ui_print "  Azenith-AI Gaming Booster ${TXVER:-v2.6.1}"
ui_print "  scan dinamis + FPS sustain (FPSGO) + WebUI"
ui_print "*********************************************"

[ -n "$API" ] && [ "$API" -lt 28 ] && abort "! Butuh Android 9 (API 28) atau lebih baru."

if   [ -n "$KSU" ];    then ui_print "- Root manager: KernelSU"
elif [ -n "$APATCH" ]; then ui_print "- Root manager: APatch"
else                        ui_print "- Root manager: Magisk ${MAGISK_VER:-}"; fi

ui_print "- Mengatur permission"
set_perm_recursive "$MODPATH" 0 0 0755 0644
for f in post-fs-data.sh service.sh uninstall.sh safe_trigger.sh support.sh common.sh action.sh \
         lib/core.sh lib/scan.sh lib/thermal.sh lib/perf.sh lib/fps.sh lib/fpsgo.sh lib/misc.sh lib/daemon.sh \
         lib/supervisor.sh lib/daemon_run.sh lib/kernel_match.sh lib/devinfo.sh lib/thermalkill.sh lib/tkloop.sh lib/bypass.sh lib/app_install.sh system/bin/azenith-ai; do
  [ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done

DATA=/data/adb/azenith-ai
mkdir -p "$DATA"
# konfigurasi v1 (kunci berbeda) disimpan sebagai cadangan, config baru dibuat saat boot
if [ -f "$DATA/azenith-ai.conf" ] && ! grep -q '^CONF_VERSION=2' "$DATA/azenith-ai.conf"; then
  mv -f "$DATA/azenith-ai.conf" "$DATA/azenith-ai.conf.v1.bak"
  ui_print "- Config lama dicadangkan: azenith-ai.conf.v1.bak (format berubah di v2)"
fi
rm -f "$DATA/boot_count" "$DATA/safe_mode"
rm -f "$DATA/scan/profile.conf"   # paksa scan ulang

# Disable Thermal sekarang fitur inti permanen (bukan toggle di WebUI lagi).
# Paksa THERMAL_KILL=1 & lepas kunci Bypass Thermal walau conf lama (update dari versi sebelumnya) masih 0.
if [ -f "$DATA/azenith-ai.conf" ]; then
  if grep -q '^THERMAL_KILL=' "$DATA/azenith-ai.conf"; then
    sed -i 's/^THERMAL_KILL=.*/THERMAL_KILL=1/' "$DATA/azenith-ai.conf"
  else
    echo 'THERMAL_KILL=1' >> "$DATA/azenith-ai.conf"
  fi
  sed -i 's/^BYPASS_THERMAL=1/BYPASS_THERMAL=0/' "$DATA/azenith-ai.conf" 2>/dev/null
  ui_print "- Disable Thermal: dijadikan otomatis permanen (THERMAL_KILL=1)"
fi

if [ -f "$MODPATH/app/AzenithAI-Companion.apk" ]; then
  ui_print "- Companion App: ikut di zip ini, dipasang otomatis saat boot (pm install)"
  ui_print "  (app butuh izin root dari Manager saat pertama dibuka)"
else
  ui_print "- Companion App: APK tidak ada di zip ini (taruh di app/AzenithAI-Companion.apk)"
fi
ui_print "- Selesai. Reboot, lalu cek:  su -c azenith-ai status"
ui_print "  Tahan Volume UP saat boot = safe mode (skip)."
